# LORD JM Amplifier

Samsung/Android starter project with:
- PIN gate: LORDJM
- Neon red + black UI
- LORD JM logo
- Amplifier ON/OFF
- Mic gain, echo, loudness, bass and treble controls
- Animated level display
- WhatsApp launch button
- Android microphone permission handling
- Basic real-time microphone-to-speaker audio engine

## Build
Open this folder in Android Studio and let Gradle sync. Then Run on a Samsung device.

## Notes
Real-time microphone amplification can produce feedback/howling, especially with the phone speaker near the microphone. Use headphones or keep the speaker volume moderate while testing. Bass/treble sliders are currently UI controls; the audio engine's gain/echo/loudness are active in this starter version.
