package com.lordjm.amplifier

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlin.math.*

private val NeonRed = Color(0xFFFF1744)
private val DeepRed = Color(0xFF8B001B)
private val Black = Color(0xFF050505)
private val Card = Color(0xFF111111)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        setContent { LordJMApp() }
    }
}

@Composable
fun LordJMApp() {
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = NeonRed,
        background = Black,
        surface = Card
    )) {
        if (!unlocked) {
            PinScreen(pin) {
                if (pin == "LORDJM") unlocked = true
            } onPinChange@{ value -> 
                if (value.length <= 6) pin = value.uppercase()
            }
        } else {
            AmplifierScreen()
        }
    }
}

@Composable
fun PinScreen(pin: String, onUnlock: () -> Unit, onPinChange: (String) -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color(0xFF240008), Black), radius = 900f)
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Image(
                painter = androidx.compose.ui.res.painterResource(R.drawable.lord_jm_logo),
                contentDescription = "LORD JM",
                modifier = Modifier.size(190.dp).clip(CircleShape)
            )
            Spacer(Modifier.height(20.dp))
            Text("LORD JM AMPLIFIER", color = NeonRed, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("ENTER KEY", color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = onPinChange,
                singleLine = true,
                label = { Text("PIN / KEY") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonRed,
                    unfocusedBorderColor = Color.DarkGray,
                    focusedLabelColor = NeonRed
                ),
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onUnlock,
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.width(180.dp).height(52.dp)
            ) { Text("UNLOCK", color = Color.White, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun AmplifierScreen() {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(false) }
    var gain by remember { mutableFloatStateOf(1.5f) }
    var echo by remember { mutableFloatStateOf(0.15f) }
    var loud by remember { mutableFloatStateOf(0.5f) }
    var bass by remember { mutableFloatStateOf(0.5f) }
    var treble by remember { mutableFloatStateOf(0.5f) }
    var engine by remember { mutableStateOf<MicAmplifier?>(null) }

    DisposableEffect(enabled, gain, echo, loud) {
        if (enabled) {
            val amp = MicAmplifier(gain, echo, loud)
            engine = amp
            amp.start()
        } else {
            engine?.stop()
            engine = null
        }
        onDispose {
            engine?.stop()
            engine = null
        }
    }

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.85f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse"
    )

    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF090909), Color(0xFF160006), Black))
        ).verticalScroll(rememberScrollState()).padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = androidx.compose.ui.res.painterResource(R.drawable.lord_jm_logo),
                contentDescription = null,
                modifier = Modifier.size(64.dp).clip(CircleShape)
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("LORD JM", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("AMPLIFIER", color = NeonRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.weight(1f))
            Surface(shape = CircleShape, color = if (enabled) NeonRed.copy(alpha=.2f) else Color.DarkGray) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                    Text(if (enabled) "ON" else "OFF", color = if (enabled) NeonRed else Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(22.dp))

        Box(
            Modifier.fillMaxWidth().height(160.dp)
                .border(2.dp, if (enabled) NeonRed else Color.DarkGray, RoundedCornerShape(28.dp))
                .background(Color(0xFF0B0B0B), RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(19) { i ->
                    val h = if (enabled) (20 + abs(sin(i * 0.8)) * 80 * pulse).dp else 12.dp
                    Box(Modifier.width(4.dp).height(h).clip(RoundedCornerShape(4.dp)).background(if (enabled) NeonRed else Color.DarkGray))
                }
            }
            Text(if (enabled) "MIC LIVE" else "AMPLIFIER OFF", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { enabled = !enabled },
            modifier = Modifier.fillMaxWidth().height(62.dp),
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (enabled) DeepRed else NeonRed)
        ) {
            Text(if (enabled) "⏹  TURN OFF" else "▶  TURN ON AMPLIFIER", fontSize = 17.sp, fontWeight = FontWeight.Black)
        }

        Spacer(Modifier.height(18.dp))
        ControlCard("MIC GAIN", gain, 1f..3f) { gain = it }
        ControlCard("ECHO", echo, 0f..0.8f) { echo = it }
        ControlCard("LOUDNESS", loud, 0f..1f) { loud = it }
        ControlCard("BASS", bass, 0f..1f) { bass = it }
        ControlCard("TREBLE", treble, 0f..1f) { treble = it }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = {
                val intent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (intent != null) context.startActivity(intent)
                else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")))
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            border = BorderStroke(2.dp, NeonRed),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("💬  OPEN WHATSAPP", color = NeonRed, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "LORD JM • Neon Red Edition",
            color = Color.Gray, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
fun ControlCard(title: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
    ) {
        Column(Modifier.padding(horizontal = 15.dp, vertical = 10.dp)) {
            Row {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(String.format("%.0f%%", ((value-range.start)/(range.endInclusive-range.start))*100), color = NeonRed, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = value,
                onValueChange = onChange,
                valueRange = range,
                colors = SliderDefaults.colors(
                    thumbColor = NeonRed,
                    activeTrackColor = NeonRed,
                    inactiveTrackColor = Color.DarkGray
                )
            )
        }
    }
}

class MicAmplifier(
    private val gain: Float,
    private val echo: Float,
    private val loud: Float
) {
    private var recording: AudioRecord? = null
    private var playing: AudioTrack? = null
    private var job: Job? = null

    fun start() {
        if (job != null) return
        val sampleRate = 44100
        val min = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (min <= 0) return
        val bufferSize = max(min * 2, 4096)
        recording = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize
        )
        playing = AudioTrack(
            AudioManager.STREAM_MUSIC, sampleRate,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
            bufferSize, AudioTrack.MODE_STREAM
        )
        recording?.startRecording()
        playing?.play()
        job = CoroutineScope(Dispatchers.Default).launch {
            val buf = ShortArray(bufferSize / 2)
            val delayBuf = ShortArray(sampleRate / 3)
            var delayIndex = 0
            while (isActive) {
                val n = recording?.read(buf, 0, buf.size) ?: break
                if (n > 0) {
                    for (i in 0 until n) {
                        val dry = buf[i].toFloat()
                        val delayed = delayBuf[delayIndex].toFloat()
                        var out = dry * gain + delayed * echo
                        out *= (1f + loud)
                        buf[i] = out.coerceIn(-32768f, 32767f).toInt().toShort()
                        delayBuf[delayIndex] = dry.toInt().coerceIn(-32768, 32767).toShort()
                        delayIndex = (delayIndex + 1) % delayBuf.size
                    }
                    playing?.write(buf, 0, n)
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        try { recording?.stop() } catch (_: Exception) {}
        try { playing?.stop() } catch (_: Exception) {}
        recording?.release()
        playing?.release()
        recording = null
        playing = null
    }
}
